<?php
    require_once __DIR__ . '/db_config.php';
	
session_start();


		$user=$_SESSION["user_logueado"];
        $con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE) or die(mysql_error());
        if (!$con)
        {
            die("No se ha podido realizar la corrección ERROR:" . mysqli_connect_error() . "<br>");
        }
        
        else
        {
            mysqli_set_charset ($con, "utf8");
            
        }
        $suma = "SELECT SUM(precio) FROM carrito$user;";
		?>
		<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- /Bootstrap --> 

</head>
<body background="/img/blanco.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: cover;">
<div class="container-fluid" height="100%">
  <div class="row" >
      <div class="col-3">
		
	  </div>
          <div class="col-6">
	<h1 align="center" style="color:white">Bienvenido/a: <?php echo $user?></h1>
	<br>
    <H1 align="center" style="background:blue">CARRITO COMPRA</H1>
    <div class="text-center">
        <form method="post">
    <button style='width:25%;' type="button" onclick="location.href='menu_cliente.php'" class="btn btn-secondary btn-lg">Atras</button>   
    <button style='width:25%;' type='submit' name='Comprar' class='btn btn-success btn-lg'>Comprar</button>
        </form>
    
    <div>
</div>

</body>

</html>
		
<?php
    $sqlquery = "SELECT * FROM carrito$user";
    $resultado = mysqli_query($con,$sqlquery);
    $prueba =  "SELECT count(*) as total FROM carrito$user";
    $resultado2 = mysqli_query($con,$prueba);
    $datos = mysqli_fetch_assoc($resultado2);
	
	if ($datos['total'] == 0)
	{
        echo "<h1 align='center'>EL CARRITO ESTA VACIO</h1>";
    } 
    while($printar = $resultado->fetch_assoc()){
        $idproducto = $printar["idproducto"];
        $producto = $printar["producto"];
        $precio = $printar["precio"];
        

        echo '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">';
        echo  '<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>';
        echo "<div align='center' class='table '>";
        echo " <form method='POST'>";
        echo "<tr> <br>";
        echo "<td>". $producto . "   </td>";
        echo "<td>(". $precio . "  euros) </td>";        
        echo "</tr>";
        echo "<form method='post'>";
        echo "<button type='submit' class='btn btn-danger' name='Eliminar'> Eliminar</button>";
        echo "</form>";
        echo "</div>";  
    }
    
    if(isset($_POST['Eliminar']) && $datos['total'] != 0){
        $consulta="DELETE from carrito$user where idproducto = $idproducto";
        $resultado = mysqli_query($con,$consulta);
       }
    if(isset($_POST['Comprar'])){
        $consulta2="DELETE from carrito$user";
        $resultado2 = mysqli_query($con,$consulta2);
       }
    
?>
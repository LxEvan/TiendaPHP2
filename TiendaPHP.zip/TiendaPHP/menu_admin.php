<?php
    require_once __DIR__ . '/db_config.php';
	
session_start();
			$user=$_SESSION["user_logueado"];
		
		?>
		<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- /Bootstrap --> 

</head>
<body background="/img/maxresdefault.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: cover;">
<div class="container-fluid" height="100%">
  <div class="row" >
      <div class="col-3">
		
	  </div>
          <div class="col-6">
	<h1 align="center" style="color:white">Bienvenido/a: <?php echo $user?></h1>
	<br>


	<table  class="table table-hover">
	<tr>
		<td align="center"><button style='width:25%;' width="20%" type="button" onclick="location.href='articulos_admin.php'" class="btn btn-primary btn-lg">Comprar objetos</button></td>
	</tr>
	<tr>
		<td align="center"><button style='width:25%;' width="20%" type="button" onclick="location.href='carrito_admin.php'" class="btn btn-primary btn-lg">Consultar Carrito</button></td>
 	</tr>		
	<tr>
		<td align="center"><button style='width:25%;' type="button" onclick="location.href='logout.php'" class="btn btn-secondary btn-lg">Salir</button></td>
	</tr>
	</table>
			</div>
	</div>
</div>

</body>
</html>
		
		<?php





?>
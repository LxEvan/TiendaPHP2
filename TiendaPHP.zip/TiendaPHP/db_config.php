<?php
define('DB_USER', "root"); 
define('DB_PASSWORD', "usbw"); 
define('DB_DATABASE', "UsuariosTienda"); 
define('DB_SERVER', "localhost"); 
?>
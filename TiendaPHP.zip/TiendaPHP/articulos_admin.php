<?php
    require_once __DIR__ . '/db_config.php';
	
session_start();


		$user=$_SESSION["user_logueado"];
        $con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE) or die(mysql_error());
        if (!$con)
        {
            die("No se ha podido realizar la corrección ERROR:" . mysqli_connect_error() . "<br>");
        }
        
        else
        {
            mysqli_set_charset ($con, "utf8");
          
        }
		?>
		<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- /Bootstrap --> 

</head>
<body background="/img/imagen2.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: cover;">
<div class="container-fluid" height="100%">
  <div class="row" >
      <div class="col-3">
		
	  </div>
          <div class="col-6">
	<h1 align="center" style="color:white">Bienvenido/a: <?php echo $user?></h1>
	<br>
    <H1 align="center" style="background:blue">¿QUE QUIERES COMPRAR?</H1>
    <form method="post">
	<table class="table ">
	<tr>
		<td align="center">
		<button style='width:25%;' width="20%" type="submit" name="objetouno" class="btn btn-primary btn-lg">Articulo comprable 1 (15€)</button>
		<button style='width:25%;' width="20%" type="submit" name="modificaruno" class="btn btn-warning btn-lg">Modificar Articulo (Subir de rango)</button>
		<button style='width:25%;' width="20%" type="submit" name="bajaruno" class="btn btn-primary btn-lg">Modificar Articulo (Bajar de rango)</button>
		</td>
	</tr>
	<tr>
		<td align="center">
		<button style='width:25%;' width="20%" type="submit" name="objetodos" class="btn btn-primary btn-lg">Articulo comprable 2 (20€)</button>
		<button style='width:25%;' width="20%" type="submit" name="modificardos" class="btn btn-warning btn-lg">Modificar Articulo (Subir de rango)</button>
		<button style='width:25%;' width="20%" type="submit" name="bajardos" class="btn btn-primary btn-lg">Modificar Articulo (Bajar de rango)</button>
		</td>
     </tr>		
     <tr>
		<td align="center">
		<button style='width:25%;' width="20%" type="submit" name="objetotres" class="btn btn-primary btn-lg">Articulo comprable 3 (25€)</button>
		<button style='width:25%;' width="20%" type="submit" name="modificartres" class="btn btn-warning btn-lg">Modificar Articulo (Subir de rango)</button>
		<button style='width:25%;' width="20%" type="submit" name="bajartres" class="btn btn-primary btn-lg">Modificar Articulo (Bajar de rango)</button>
		</td>
     </tr>
     <tr>
		<td align="center">
		<button style='width:25%;' width="20%" type="submit" name="objetocuatro" class="btn btn-primary btn-lg">Articulo comprable 4 (30€)</button>
		<button style='width:25%;' width="20%" type="submit" name="modificarcuatro" class="btn btn-warning btn-lg">Modificar Articulo (Subir de rango)</button>
		<button style='width:25%;' width="20%" type="submit" name="bajarcuatro" class="btn btn-primary btn-lg">Modificar Articulo (Bajar de rango)</button>
		</td>
     </tr>
     <tr>
		<td align="center">
		<button style='width:25%;' width="20%" type="submit" name="objetocinco" class="btn btn-primary btn-lg">Articulo comprable 5 (35€)</button>
		<button style='width:25%;' width="20%" type="submit" name="modificarcinco" class="btn btn-warning btn-lg">Modificar Articulo (Subir de rango)</button>
		<button style='width:25%;' width="20%" type="submit" name="bajarcinco" class="btn btn-primary btn-lg">Modificar Articulo (Bajar de rango)</button>
		</td>
 	</tr>
	<tr>
		<td align="center"><button style='width:25%;' type="button" onclick="location.href='menu_admin.php'" class="btn btn-secondary btn-lg">Atras</button></td>
	</tr>
	</table>
			</div>
    </div>
    </form>
</div>

</body>
</html>
		
<?php
 if(isset($_POST['objetouno'])){
     $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (1,'Articulo comprable 1', 15)";
     $resultado = mysqli_query($con,$consulta);
    } else if (isset($_POST['modificaruno'])){
	 $consulta="UPDATE carrito$user SET producto = 'Producto Modificado 1', precio = 150 WHERE id_producto = 1; ";
     $resultado = mysqli_query($con,$consulta);	
	} else if (isset($_POST['bajaruno'])){
	 $consulta="UPDATE carrito$user SET producto = 'Articulo comprable 1', precio = 15 WHERE id_producto = 1; ";
     $resultado = mysqli_query($con,$consulta);	
	}
 if(isset($_POST['objetodos'])){
    $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (2,'Articulo comprable 2', 20) ";
    $resultado = mysqli_query($con,$consulta);
	} else if (isset($_POST['modificardos'])){
		$consulta="UPDATE carrito$user SET producto = 'Producto Modificado 2', precio = 200 WHERE id_producto = 2; ";
		$resultado = mysqli_query($con,$consulta);
	} else if (isset($_POST['bajardos'])){
	 $consulta="UPDATE carrito$user SET producto = 'Articulo comprable 2', precio = 20 WHERE id_producto = 2; ";
     $resultado = mysqli_query($con,$consulta);	
	}
if(isset($_POST['objetotres'])){
    $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (3,'Articulo comprable 3', 25) ";
    $resultado = mysqli_query($con,$consulta);
	} else if (isset($_POST['modificartres'])){
	$consulta="UPDATE carrito$user SET producto = 'Producto Modificado 3', precio = 250 WHERE id_producto = 3; ";
	$resultado = mysqli_query($con,$consulta);
	} else if (isset($_POST['bajartres'])){
	 $consulta="UPDATE carrito$user SET producto = 'Articulo comprable 3', precio = 25 WHERE id_producto = 3; ";
     $resultado = mysqli_query($con,$consulta);	
	}
if(isset($_POST['objetocuatro'])){
    $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (4,'Articulo comprable 4', 30) ";
    $resultado = mysqli_query($con,$consulta);
	} else if (isset($_POST['modificarcuatro'])){
		$consulta="UPDATE carrito$user SET producto = 'Producto Modificado 4', precio = 300 WHERE id_producto = 4; ";
		$resultado = mysqli_query($con,$consulta);
	} else if (isset($_POST['bajarcuatro'])){
	 $consulta="UPDATE carrito$user SET producto = 'Articulo comprable 4', precio = 30 WHERE id_producto = 4; ";
     $resultado = mysqli_query($con,$consulta);	
	}
if(isset($_POST['objetocinco'])){
    $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (5,'Articulo comprable 5', 35) ";
    $resultado = mysqli_query($con,$consulta);
	} else if (isset($_POST['modificarcinco'])){
		$consulta="UPDATE carrito$user SET producto = 'Producto Modificado 5', precio = 350 WHERE id_producto = 5; ";
		$resultado = mysqli_query($con,$consulta);
	} else if (isset($_POST['bajarcinco'])){
	 $consulta="UPDATE carrito$user SET producto = 'Articulo comprable 5', precio = 35 WHERE id_producto = 5; ";
     $resultado = mysqli_query($con,$consulta);	
	}



?>
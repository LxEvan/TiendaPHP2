<?php
    require_once __DIR__ . '/db_config.php';
	
header("Content-Type: text/html;charset=utf-8");
if (isset($_POST["user"]))
{
	$user = $_POST["user"];
	$password = $_POST["password"];
	$password2 = $_POST["password2"];
	$correo = $_POST["correo"];

	if ($password != $password2){
		die("Las contraseñas no son iguales, vuelve a intentarlo");
	}
	$con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE) or die(mysql_error());
	
	if (!$con)
	{
		die("No se ha podido realizar la corrección ERROR:" . mysqli_connect_error() . "<br>");
	}
	
	else
	{
		mysqli_set_charset ($con, "utf8");
		echo "Se ha conectado a la base de datos"."<br>";
	}
	//////////////////////////////////////
	
	//Inserción de datos
	
	//Primero compruebo si el nick existe
	$instruccion = "select count(*) as cuantos from ListaUsuarios where user = '$user'";
	$res = mysqli_query($con, $instruccion);
	$datos = mysqli_fetch_assoc($res);
	
	if ($datos['cuantos'] == 0)
	{
		$instruccion = "insert into ListaUsuarios values (null,'$user','$password','$correo')";
		$res = mysqli_query($con, $instruccion);
		if (!$res) 
		{
			die("No se ha podido crear el usuario");
		}
		else
		{
			echo "Usuario creado";
			//me lleva al login para que pruebe mi contraseña
			echo "<script>alert('Usuario creado correctamente');</script>";
			$instruccion = "CREATE TABLE IF NOT EXISTS `carrito$user` (
				`id_producto` int(11) NOT NULL ,
				`producto` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
				`precio` int(10) NOT NULL,
				`idproducto` int(11) NOT NULL AUTO_INCREMENT,
				PRIMARY KEY (`idproducto`)
			  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=1 ";
			echo "<script>alert('Carrito creado correctamente');</script>";
			$res = mysqli_query($con, $instruccion);
			include_once("login.html");
		}
	}
	else
	{
		echo "El nombre de usuario $user no está disponible";
	}

}
else 
{
	echo ("ERROR: No se puede introducir un nombre de usuario en blanco");
}
?>
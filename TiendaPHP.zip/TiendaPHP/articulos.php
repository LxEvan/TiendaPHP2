<?php
    require_once __DIR__ . '/db_config.php';
	
session_start();


		$user=$_SESSION["user_logueado"];
        $con = mysqli_connect(DB_SERVER, DB_USER, DB_PASSWORD, DB_DATABASE) or die(mysql_error());
        if (!$con)
        {
            die("No se ha podido realizar la corrección ERROR:" . mysqli_connect_error() . "<br>");
        }
        
        else
        {
            mysqli_set_charset ($con, "utf8");
            echo "Se ha conectado a la base de datos"."<br>";
            echo "carrito$user";
        }
		?>
		<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!-- /Bootstrap --> 

</head>
<body background="/img/imagen2.jpg" style="background-repeat: no-repeat; background-attachment: fixed; background-size: cover;">
<div class="container-fluid" height="100%">
  <div class="row" >
      <div class="col-3">
		
	  </div>
          <div class="col-6">
	<h1 align="center" style="color:white">Bienvenido/a: <?php echo $user?></h1>
	<br>
    <H1 align="center" style="background:blue">¿QUE QUIERES COMPRAR?</H1>
    <form method="post">
	<table  class="table table-hover">
	<tr>
		<td align="center"><button style='width:25%;' width="20%" type="submit" name="objetouno" class="btn btn-primary btn-lg">Articulo comprable 1 (15€)</button></td>
	</tr>
	<tr>
		<td align="center"><button style='width:25%;' width="20%" type="submit" name="objetodos" onclick="" class="btn btn-primary btn-lg">Articulo comprable 2 (20€)</button></td>
     </tr>		
     <tr>
		<td align="center"><button style='width:25%;' width="20%" type="submit" name="objetotres" onclick="" class="btn btn-primary btn-lg">Articulo comprable 3 (25€)</button></td>
     </tr>
     <tr>
		<td align="center"><button style='width:25%;' width="20%" type="submit" name="objetocuatro" onclick="" class="btn btn-primary btn-lg">Articulo comprable 4 (30€)</button></td>
     </tr>
     <tr>
		<td align="center"><button style='width:25%;' width="20%" type="submit" name="objetocinco" class="btn btn-primary btn-lg">Articulo comprable 5 (35€)</button></td>
 	</tr>
	<tr>
		<td align="center"><button style='width:25%;' type="button" onclick="location.href='menu_cliente.php'" class="btn btn-secondary btn-lg">Atras</button></td>
	</tr>
	</table>
			</div>
    </div>
    </form>
</div>

</body>
</html>
		
<?php
 if(isset($_POST['objetouno'])){
     $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (1,'Articulo comprable 1', 15)";
     $resultado = mysqli_query($con,$consulta);
    }
 if(isset($_POST['objetodos'])){
    $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (2,'Articulo comprable 2', 20) ";
    $resultado = mysqli_query($con,$consulta);
}
if(isset($_POST['objetotres'])){
    $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (3,'Articulo comprable 3', 25) ";
    $resultado = mysqli_query($con,$consulta);
}
if(isset($_POST['objetocuatro'])){
    $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (4,'Articulo comprable 4', 30) ";
    $resultado = mysqli_query($con,$consulta);
}
if(isset($_POST['objetocinco'])){
    $consulta="INSERT INTO carrito$user (id_producto, producto, precio) values (5,'Articulo comprable 5', 35) ";
    $resultado = mysqli_query($con,$consulta);
}



?>